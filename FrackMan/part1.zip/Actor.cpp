#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

Actor::Actor(StudentWorld* s, int imageID, int startX, int startY, Direction dir, double size, unsigned int depth)
	: GraphObject(imageID, startX, startY, dir, size, depth)
{
	m_student = s;
	setVisible(true);
}

Actor::~Actor()
{
	setVisible(false);
}

StudentWorld * Actor::getStudent() const
{
	return m_student;
}


Dirt::Dirt(StudentWorld* s, int x, int y)
	:Actor(s, IID_DIRT, x, y, right, .25, 3)
{
}

Dirt::~Dirt()
{
	setVisible(false);
}

void Dirt::doSomething()
{
	return;
}

FrackMan::FrackMan(StudentWorld* s)
	:Actor(s, IID_PLAYER, 30, 60)
{
	m_hitPoints = 10;
	m_water = 5;
	m_solar = 1;
	m_nuggets = 0;
}

FrackMan::~FrackMan()
{
	setVisible(false);
}

void FrackMan::doSomething()
{
	if (!isAlive())
		return;
	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 4; j++)
		{
			if (getY() + j >= 60)
			{
				continue;
			}
			if (getStudent()->isDirt(getX() + i, getY() + j))
				getStudent()->removeDirt(getX() + i, getY() + j);

		}
	{
		int value;
		if (getStudent()->getKey(value))
		{
			switch (value)
			{
			case KEY_PRESS_LEFT:
				if (getDirection() != left)
					setDirection(left);
				else if (getX() != 0)
					moveTo(getX() - 1, getY());
				return;
			case KEY_PRESS_UP:
				if (getDirection() != up)
					setDirection(up);
				else if (getY() != 60)
					moveTo(getX(), getY() + 1);
				return;
			case KEY_PRESS_RIGHT:
				if (getDirection() != right)
					setDirection(right);
				else if (getX() != 60)
					moveTo(getX() + 1, getY());
				return;
			case KEY_PRESS_DOWN:
				if (getDirection() != down)
					setDirection(down);
				else if (getY() != 0)
					moveTo(getX(), getY() - 1);
				return;
			}
		}
	}
	return;
}

bool FrackMan::isAlive() const
{
	if (m_hitPoints == 0)
		return false;
	return true;
}
