#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* s, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0);
	virtual ~Actor();
	virtual void doSomething() = 0;
	StudentWorld* getStudent() const;
private:
	StudentWorld* m_student;
};

class Dirt : public Actor
{
public:
	Dirt(StudentWorld *s, int x, int y);
	virtual ~Dirt();
	void doSomething();
private:
};

class FrackMan :public Actor
{
public:
	FrackMan(StudentWorld *s);
	virtual ~FrackMan();
	void doSomething();
	bool isAlive() const;
private:
	int m_hitPoints;
	int m_water;
	int m_solar;
	int m_nuggets;
};

#endif // ACTOR_H_
