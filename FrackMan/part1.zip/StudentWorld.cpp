#include "StudentWorld.h"
#include "Actor.h"
#include <string>

using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(std::string assetDir)
	: GameWorld(assetDir)
{
	for (int i = 0; i < 64; i++)
		for (int j = 0; j < 60; j++)
		{
			m_dirt[i][j] = nullptr;
		}
	m_frackman = nullptr;
}

StudentWorld::~StudentWorld()
{
	for (int i = 0; i < 64; i++)
		for (int j = 0; j < 60; j++)
		{
			delete m_dirt[i][j];
			m_dirt[i][j] = nullptr;
		}
	delete m_frackman;
}

int StudentWorld::init()
{
	for (int i = 0; i < 64; i++)
		for (int j = 0; j < 60; j++)
			m_dirt[i][j] = new Dirt(this, i, j);
	for (int i = 30; i <= 33; i++)
		for (int j = 4; j <= 59; j++)
		{
			delete m_dirt[i][j];
			m_dirt[i][j] = nullptr;
		}
	m_frackman = new FrackMan(this);
	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	m_frackman->doSomething();
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	for (int i = 0; i < 64; i++)
		for (int j = 0; j < 60; j++)
		{
			delete m_dirt[i][j];
		}
	delete m_frackman;
}

bool StudentWorld::isDirt(int x, int y) const
{
	if (m_dirt[x][y] != nullptr)
		return true;
	return false;
}

void StudentWorld::removeDirt(int x, int y)
{
	if (m_dirt[x][y] != nullptr)
	{
		//return;
		
			delete m_dirt[x][y];
			m_dirt[x][y] = nullptr;
			playSound(SOUND_DIG);
		
	}
}
