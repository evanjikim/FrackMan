#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class Dirt;
class FrackMan;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir);

	~StudentWorld();

	virtual int init();

	virtual int move();

	virtual void cleanUp();

	bool isDirt(int x, int y) const;

	void removeDirt(int x, int y);

private:
	Dirt* m_dirt[64][60];
	FrackMan* m_frackman;
};

#endif // STUDENTWORLD_H_
